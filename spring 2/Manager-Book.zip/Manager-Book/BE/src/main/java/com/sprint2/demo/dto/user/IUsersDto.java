package com.sprint2.demo.dto.user;

public interface IUsersDto {
    String getUsername();
    String getPassword();
    Boolean getFlag();
}
