package com.sprint2.demo.services.user;


import com.sprint2.demo.models.Roles;

public interface IRoleService {

    Roles findRoleByName(String roleUser);


}
