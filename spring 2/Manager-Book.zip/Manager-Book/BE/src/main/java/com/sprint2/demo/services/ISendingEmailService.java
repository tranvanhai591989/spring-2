//package com.sprint2.demo.services;
//
//
//import com.sprint2.demo.dto.cart.CartAndDetailDto;
//import freemarker.template.TemplateException;
//
//import javax.mail.MessagingException;
//import java.io.IOException;
//
//public interface ISendingEmailService {
//
//    void sendEmail(CartAndDetailDto cartAndDetailDto) throws MessagingException, IOException, TemplateException;
//
//}
