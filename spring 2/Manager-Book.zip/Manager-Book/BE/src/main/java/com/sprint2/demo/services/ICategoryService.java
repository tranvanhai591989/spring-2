package com.sprint2.demo.services;

import com.sprint2.demo.models.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> findAllCategory();
}
