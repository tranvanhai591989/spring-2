package com.sprint2.demo.repository.user;

public interface UsersDetails {
}
