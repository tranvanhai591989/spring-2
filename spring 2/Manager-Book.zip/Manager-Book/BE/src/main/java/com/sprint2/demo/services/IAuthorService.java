package com.sprint2.demo.services;

import com.sprint2.demo.models.Author;

import java.util.List;

public interface IAuthorService {
    List<Author> findAllAuthor();
}
