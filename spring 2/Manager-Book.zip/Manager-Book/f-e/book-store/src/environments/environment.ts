// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080',
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
   firebaseConfig : {
    apiKey: 'AIzaSyAQYS5x1uG7__4Ya3KtRGXTJRSP4uwt3HA',
    authDomain: 'quangtruong-6969c.firebaseapp.com',
    databaseURL :'https://quangtruong-6969c-default-rtdb.firebaseio.com/',
    projectId: 'quangtruong-6969c',
    storageBucket: 'quangtruong-6969c.appspot.com',
    messagingSenderId: '629009810116',
    appId: '1:629009810116:web:603b445746865b35d97f91',
    measurementId: 'G-7SJCV7NBR7'
  }


};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
