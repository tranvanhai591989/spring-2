import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access-denined',
  templateUrl: './access-denined.component.html',
  styleUrls: ['./access-denined.component.css']
})
export class AccessDeninedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
