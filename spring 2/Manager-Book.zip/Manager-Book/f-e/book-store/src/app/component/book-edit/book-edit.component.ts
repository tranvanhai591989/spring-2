import {Component, EventEmitter, Inject, OnInit} from '@angular/core';
import {BookDto} from '../../model/BookDto';
import {Author} from '../../model/Author';
import {Category} from '../../model/Category';
import {Discount} from '../../model/Discount';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';
import {BookService} from '../../service/book.service';
import {AuthorService} from '../../service/author.service';
import {CategoryService} from '../../service/category.service';
import {ToastrService} from 'ngx-toastr';
import {DiscountService} from '../../service/discount.service';
import {Observable} from 'rxjs';
import {finalize} from 'rxjs/operators';
import {AngularFireStorage} from '@angular/fire/storage';
import {formatDate} from '@angular/common';

@Component({
  selector: 'app-book-edit',
  templateUrl: './book-edit.component.html',
  styleUrls: ['./book-edit.component.css']
})
export class BookEditComponent implements OnInit {
  bookDto: BookDto;
  authorList: Author[];
  categoryList: Category[];
  discountList: Discount[];
  id: number;
  image: string;
  selectedImage: any = null;
  downloadURL: string;
  listIMG: Array<string> = [];
  checkUploadAvatar = false;
  giveURLtoCreate = new EventEmitter<string>();
  selectedFile: File;
  display: string;
  myMap = new Map();
  errorUser: string;
  errorImage: string;


  updateForm = new FormGroup({
    id: new FormControl(''),
    name: new FormControl(''),
    code: new FormControl(''),
    translator: new FormControl([Validators.required]),
    publisher: new FormControl(''),
    totalPage: new FormControl(''),
    dimension: new FormControl(''),
    releaseDate: new FormControl(''),
    quantity: new FormControl(''),
    price: new FormControl(''),
    description: new FormControl(''),
    image: new FormControl(''),
    status: new FormControl(''),
    author: new FormControl(''),
    category: new FormControl(''),
    discount: new FormControl(''),

  });


  constructor(private router: Router,
              private bookService: BookService,
              private authorService: AuthorService,
              private categoryService: CategoryService,
              private discountService: DiscountService,
              private activatedRoute: ActivatedRoute,
              private toastrService: ToastrService,
              @Inject(AngularFireStorage) private storage: AngularFireStorage) {

    scrollBy(0, 0);
    this.activatedRoute.paramMap.subscribe((paramMap: ParamMap) => {
      this.id = +paramMap.get('id');
      console.log(this.bookService.findBookById(this.id).subscribe(
        d => console.log(d)
      ));
    });
  }

  showPreview(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      // tslint:disable-next-line:prefer-const
      let reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]); // read file as data url
      this.selectedImage = event.target.files[0];
      // tslint:disable-next-line:no-shadowed-variable
      reader.onload = (event) => { // called once readAsDataURL is completed
        // @ts-ignore
        this.displayImage();
      };
    }
    this.image = '';
  }


  compareWithId(item1, item2) {
    return item1 && item2 && item1.id === item2.id;
  }


  ngOnInit(): void {
    this.getListCategory();
    this.getListAuthor();
    this.getListDiscount();
  }

  getBook(index: number) {
    return this.bookService.findBookById(index).subscribe(item => {
      this.bookDto = item;
      this.updateForm.patchValue(item);
      this.image = this.bookDto.image;
      console.log(this.bookDto.image);
    }, error => {
      this.toastrService.warning('Không tìm thấy mã khách hàng ! ', '', {
        timeOut: 3000,
        progressBar: true
      });
      this.router.navigateByUrl('/edit');
    });
  }


  getListAuthor() {
    this.authorService.getAllAuthor().subscribe(list => {
      this.authorList = list;
    });
    this.getBook(this.id);
  }

  getListCategory() {
    this.categoryService.getAllCategory().subscribe(list => {
      this.categoryList = list;
    });
    this.getBook(this.id);
  }

  getListDiscount() {
    this.discountService.getAllDiscount().subscribe(list => {
      this.discountList = list;
    });
    this.getBook(this.id);
  }


  update(index: number) {
    if (!this.updateForm.valid) {
      this.updateForm.markAllAsTouched();
    const value = this.updateForm.value;
    this.bookService.update(index, value).subscribe(() => {
      }, error => {
        this.toastrService.warning('Bắt buộc phải nhập đúng thông tin !', 'Thông báo', {
          timeOut: 3000,
          progressBar: true
        });

      },
      () => {
        this.toastrService.success('Chỉnh sửa thành công !', 'Thông báo', {
          timeOut: 3000,
          progressBar: true
        });
        this.router.navigateByUrl('');
      }
    )  } else {
      const nameImg = this.getCurrentDateTime() + this.selectedImage.name;
      const fileRef = this.storage.ref(nameImg);
      this.storage.upload(nameImg, this.selectedImage).snapshotChanges().pipe(finalize(() => {
        fileRef.getDownloadURL().subscribe(url => {
          this.updateForm.patchValue(this.bookDto.image = url);
// Call API to update
          this.updateForm.patchValue(this.bookDto.image = url);
          this.bookService.update(this.id, this.bookDto).subscribe(() => {
            this.toastrService.success('Chỉnh Sửa Thành Công !', 'Thông báo', {
              timeOut: 3000,
              progressBar: true
            });
            this.router.navigateByUrl('');
          }, error => {
            this.errorUser = error.error.errorMap.usersName;
            this.errorImage = error.error.errorMap.employeeImage;
          });
        });
      })).subscribe();

    }
  }

  getCurrentDateTime(): string {
    return formatDate(new Date(), 'dd-MM-yyyyhhmmssa', 'en-US');
  }

  displayImage() {
    this.checkUploadAvatar = true;
    const nameImg = this.getCurrentDateTime() + this.selectedImage.name;
    const fileRef = this.storage.ref(nameImg);
    this.storage.upload(nameImg, this.selectedImage).snapshotChanges().pipe(
      finalize(() => {
        fileRef.getDownloadURL().subscribe(url => {
          this.downloadURL = url;
          this.giveURLtoCreate.emit(this.downloadURL);
          this.checkUploadAvatar = false;
          this.listIMG.push(url);
          for (let i = 0; i < this.listIMG.length; i++) {
            this.myMap.set(i, this.listIMG[i]);
          }
        });
      })).subscribe();
  }
}
