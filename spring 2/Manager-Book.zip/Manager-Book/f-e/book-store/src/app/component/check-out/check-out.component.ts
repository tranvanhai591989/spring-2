import {Component, OnInit} from '@angular/core';
import {ICreateOrderRequest, IPayPalConfig} from 'ngx-paypal';
import {Router} from '@angular/router';
import {CheckOutService} from '../../service/check-out.service';
import {CartService} from '../../service/cart.service';
import {ToastrService} from 'ngx-toastr';
import {NgxSpinnerService} from 'ngx-spinner';
import {CartAndDetailDto} from '../../model/CartAndDetailDto';
import {Customer} from '../../model/Customer';
import {BookDto} from '../../model/BookDto';
import {Discount} from '../../model/Discount';


@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})


export class CheckOutComponent implements OnInit {
  cartAndDetailDto = {} as CartAndDetailDto;
  customer = {} as Customer;
  public payPalConfig ?: IPayPalConfig;
  rate = 23315;
  totalUSD: string;
  isSuccess = false;
  isError = false;
  book: BookDto;
  discounts: Discount;
  submitted = false;
  constructor(private route: Router,
              private checkOutService: CheckOutService,
              private cartService: CartService,
              private spinner: NgxSpinnerService,
              private toastr: ToastrService) {
  }

  ngOnInit(): void {

    this.checkOutService.getCartAndDetail().subscribe(value => {
      this.cartAndDetailDto = value;
      if (this.cartAndDetailDto.customer != null) {
        this.customer = this.cartAndDetailDto.customer;
      }
      this.initConfig();
    });
  }

  private initConfig(): void {

    this.payPalConfig = {
      currency: 'USD',
      clientId: 'AT8UQtN25w359hCI-3YMbFi_PcFQHN42BKg0snkpR55uDDNT0Sf11UqTbXeS0WL-JU2jnpxRtyOU7p6z',
      createOrderOnClient: (data) => <ICreateOrderRequest> {
        intent: 'CAPTURE',
        purchase_units: [{
          amount: {
            currency_code: 'USD',
            value: this.totalUSD,
            breakdown: {
              item_total: {
                currency_code: 'USD',
                value: this.totalUSD
              }
            }
          },
          items: [{
            name: 'product 1',
            quantity: '1',
            unit_amount: {
              currency_code: 'USD',
              value: this.totalUSD,
            },
          }]
        }]
      },
      advanced: {
        commit: 'true',
        extraQueryParams: [{name: 'disable-funding', value: 'credit,card'}]
      },
      style: {
        label: 'pay',
        shape: 'pill',
        layout: 'vertical',
      },
      onApprove: (data, actions) => {
        this.checkOutService.sendEmail(this.cartAndDetailDto).subscribe(value => {
          console.log(value);
          console.log(this.cartAndDetailDto.total);
        });
        this.spinner.show();
        console.log('onApprove - transaction was approved, but not authorized', data, actions);
        actions.order.get().then(details => {
          console.log('onApprove - you can get full order details inside onApprove: ', details);
        });
      },
      onClientAuthorization: (data) => {
        console.log('onClientAuthorization - you should probably inform your server about completed transaction at this point', data);
        this.checkOutService.saveCartAndDetailAPI(this.cartAndDetailDto).subscribe(data => {
          console.log(this.cartAndDetailDto);
          this.cartAndDetailDto = {};
          this.isSuccess = true;
          this.isError = false;
          this.cartService.clearCart();
          this.spinner.hide();
          this.showMessageSuccess();
          // this.openModal();
          this.route.navigate(['']).then();
        });
      },
      onCancel: (data, actions) => {
        console.log('OnCancel', data, actions);
      },
      onError: err => {
        console.log('OnError', err);
        this.isSuccess = false;
        this.isError = true;
        this.openModal();
      },
      onClick: (data, actions) => {
        this.changeRate();
        // this.checkOutService.sendEmail(this.customer).subscribe(value => {
        //   console.log(value);
        // });
        // this.cartAndDetailDto.customer = this.customerForm.value;
        if (this.customer != null) {
          this.cartAndDetailDto.customer.id = this.customer.id;
        }
        console.log(this.cartAndDetailDto.customer);
        this.submitted = true;
        console.log('onClick', data, actions);
      }
    };
  }

  onSubmit() {
    this.submitted = true;
    this.enviarEmail();
  }

  private enviarEmail() {
    this.checkOutService.saveCartAndDetailAPI(this.cartAndDetailDto.customer)
      .subscribe(data => console.log(data));
  }


  openModal() {
    document.getElementById('buttonModal').click();
  }

  returnHome() {
    this.route.navigate(['']).then();
  }

  changeRate() {
    this.totalUSD = (this.cartAndDetailDto.total / this.rate).toFixed(2);
  }

  showMessageSuccess() {

    this.toastr.success('Thanh toán đơn hàng thành công', 'Thanh toán thành công', {
      timeOut: 2000,
      progressBar: true,
    });
  }
}
