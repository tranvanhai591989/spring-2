export interface SignInRequest{
  username?:string;
  password?:string
}
