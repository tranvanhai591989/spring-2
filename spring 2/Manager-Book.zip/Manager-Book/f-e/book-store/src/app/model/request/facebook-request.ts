export interface FacebookRequest {
  email?:string;
  gender?:string;
  accessToken?:string;
  location?:string;
}
