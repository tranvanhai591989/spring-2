export interface Discount {
  id: number;
  percent: number;
}
