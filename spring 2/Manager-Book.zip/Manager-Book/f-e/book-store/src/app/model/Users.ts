export interface Users {
  username?: string;
  password?: string;
  flag?: boolean;
}
